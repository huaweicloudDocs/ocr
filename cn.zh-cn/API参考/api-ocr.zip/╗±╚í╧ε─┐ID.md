# 获取项目ID<a name="ocr_03_0130"></a>

## 从控制台获取项目ID<a name="section19885123154616"></a>

1.  登录[管理控制台](https://console.huaweicloud.com/console/?locale=zh-cn)。
2.  鼠标移动到右上角的用户名上，在下拉列表中选择“我的凭证“。
3.  在“我的凭证“页面，可以查看用户名、账号名，在项目列表中查看项目ID。

    **图 1**  查看项目ID<a name="fig20626132135515"></a>  
    ![](figures/查看项目ID.png "查看项目ID")

    多项目时，展开“所属区域”，从“项目ID”列获取子项目ID。项目编码需与NLP服务终端节点保持一致，当访问华北-北京四的终端节点（即nlp-ext.**_cn-north-4_**.myhuaweicloud.com时），项目对应需为_**cn-north-4**_。


